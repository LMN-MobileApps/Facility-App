var mongo = {
    "mongoURL": "myUserAdmin:abc123@localhost:27017",
    "loadCollection": "ticket-status",
    "targetDB": "efp"
};

module.exports = mongo;