# Installation​
## The Ionic CLI can be installed globally with npm:

$ npm install -g @ionic/cli

cd Facility-UI

$ npm install

$ ionic serve
 
 will run the app in http://localhost:8100/


## Routing for the Application :
Login Page - 
http://localhost:8100/login

Home Page for menu - 
http://localhost:8100/home

Dashboard with Tabs : 
http://localhost:8100/main/tabs/dashboard

## Adding New Modules/Page
$ ionic g page mymodule

## Adding New Components
$ ionic g component mycomponent
