const mongoose = require('mongoose');
var Schema = mongoose.Schema;
var schema = new Schema({
    userId: {type: String},
    userRole: {type: String},
    active:{type:Boolean}
 },{strict: false, '__v': false });

var FacilityUser = mongoose.model('facility_users', schema, 'facility_users');

module.exports= class UserRepository{
    resArray=[];
    getUsers(callback){
        FacilityUser.find((err, docs) => {
            if(!err) { this.resArray=docs;console.log(this.resArray);callback(this.resArray); }
           else { console.log('Error in retreiving Facility User : ' + JSON.stringify(err, undefined, 2)); return;}
       });
       
    }
}

//  module.exports = {FacilityUser};
