var UserRepository=require("../repository/facilityuserrepository") 
//var {FacilityUser}=require("../repository/facilityuserrepository");

module.exports= class UserService{
   
     userResult = [];
     userList =[];
    getAllActiveUsersService(callback){
         var user=new UserRepository();

         user.getUsers(function(res){
            this.userResult=res;
            let userResponse=new UserResponse();
            this.userResult.forEach(element => {
            userResponse.setResponse(element.userId,element.userRole);
            this.userList.push(userResponse);
            });
            console.log(this.userList);
         });
        
         callback(this.userList); 
      
    }
}

class UserResponse
{
    userId = "";
    userRole = "";

    setResponse(userId,userRole){
        this.userId=userId;
        this.userRole=userRole;
    }
}

// module.exports = {UserService};